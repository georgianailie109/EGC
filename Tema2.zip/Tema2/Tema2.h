#pragma once

#include "components/simple_scene.h"
#include "lab_m1/Tema2/lab_camera.h"


namespace m1
{
    class Tema2 : public gfxc::SimpleScene
    {
    public:
        Tema2();
        ~Tema2();
        struct ViewportArea
        {
            ViewportArea() : x(0), y(0), width(1), height(1) {}
            ViewportArea(int x, int y, int width, int height)
                : x(x), y(y), width(width), height(height) {}
            int x;
            int y;
            int width;
            int height;
        };

        void Init() override;

    private:
        void FrameStart() override;
        void Update(float deltaTimeSeconds) override;
        void FrameEnd() override;

        void RenderMesh(Mesh* mesh, Shader* shader, const glm::mat4& modelMatrix, bool isTerrain);
        void RenderMeshColor(Mesh* mesh, Shader* shader, const glm::mat4& modelMatrix, const glm::vec3& color);

        void OnInputUpdate(float deltaTime, int mods) override;
        void OnKeyPress(int key, int mods) override;
        void OnKeyRelease(int key, int mods) override;
        void OnMouseMove(int mouseX, int mouseY, int deltaX, int deltaY) override;
        void OnMouseBtnPress(int mouseX, int mouseY, int button, int mods) override;
        void OnMouseBtnRelease(int mouseX, int mouseY, int button, int mods) override;
        void OnMouseScroll(int mouseX, int mouseY, int offsetX, int offsetY) override;
        void OnWindowResize(int width, int height) override;
        void GenerateTreePositions(int numberOfTrees);
        float GetTerrainHeight(float x, float z);
        float random2D(const glm::vec2& st);
        float noise2D(const glm::vec2& st);
    protected:
        Mesh* CreateTerrainMesh(unsigned int numRows, unsigned int numCols, const std::string& meshName);
        Mesh* CreateCylinderMesh(const std::string& meshName, float radius, float height, int segments);
        Mesh* CreateConeMesh(const std::string& meshName, float radius, float height, int segments);
        Mesh* CreateRingMesh(const std::string& meshName, float innerRadius, float outerRadius, int segments);
        Mesh* CreateRectangleMesh(const std::string& name, const glm::vec3& color);
        Mesh* CreateTriangleMesh(const std::string& name, const glm::vec3& color);
        bool IsCollidingWithCylinder(const glm::vec3& dronePos, const glm::vec3& cylinderBase, float cylinderRadius, float cylinderHeight);
        bool IsCollidingWithSphere(const glm::vec3& dronePos, const glm::vec3& sphereCenter, float sphereRadius);
        void GeneratePackagePosition();
        implemented::Camera2* camera;
        glm::mat4 projectionMatrix;
        bool renderCameraTarget;
        float droneRotation;
        float propellerAngle;
        glm::vec3 dronePosition;
        glm::vec3 snowmanPosition;
        float droneYaw;
        float movementSpeed;
        float rotationSpeed;
        std::vector<glm::vec3> treePositions;
        std::vector<glm::vec3> snowmenPositions;
        std::vector<glm::vec3> cloudPositions;
        std::vector<glm::vec3> snowflakePositions;
        glm::vec3 treeBasePos;
        const float treeRadius = 1.2f;
        float bendRadius = 10.0f;
        float maxBendAngle = glm::radians(30.0f);
        glm::vec3 packagePosition;
        glm::vec3 destinationPosition;
        bool hasPackage = false;
        bool destinationVisible = false;
        void GenerateDestinationPosition();
        void RenderDestination();
        bool isPackageDropping = false;
        glm::vec3 droppedPackagePosition;
        float dropTimer = 0.0f;
        ViewportArea miniViewportArea;
        implemented::Camera2* miniMapCamera;
        void RenderArrow(const glm::vec3& position, float yaw, const glm::vec3& color, bool isMinimap);
        float cameraPitch = 0.0f;
        void RenderMinimap(float deltaTimeSeconds);
        void RenderArrowInFrontOfDrone();
        void GenerateSnowmenPositions(int numberOfSnowmen);
        void GenerateCloudPositions(int numberOfClouds);
        void GenerateSnowflakes(int numberOfSnowflakes);
        void UpdateSnowflakes(float deltaTime);
        void RenderSnowflakes();
        int packagesCollected;
        int score;
    };
}   // namespace m1
