﻿#include "lab_m1/Tema2/Tema2.h"

#include <vector>
#include <string>
#include <iostream>
#include <cmath>

using namespace std;
using namespace m1;

Tema2::Tema2()
{}


Tema2::~Tema2()
{}


void Tema2::Init()
{
    renderCameraTarget = false;
    propellerAngle = 0.0f;

    dronePosition = glm::vec3(50, 25, 10);
    droneYaw = 0.0f;
    movementSpeed = 10.0f;
    rotationSpeed = 2.0f;

    packagesCollected = 0;
    score = 0;

    camera = new implemented::Camera2();
    camera->Set(glm::vec3(50, 20, 90), glm::vec3(50, 0, 50), glm::vec3(0, 1, 0));

    projectionMatrix = glm::perspective(glm::radians(60.f), window->props.aspectRatio, 0.01f, 200.f);

    {
        Mesh* terrainMesh = CreateTerrainMesh(100, 100, "terrain");
        AddMeshToList(terrainMesh);
    }
    {
        Mesh* mesh = new Mesh("box");
        mesh->LoadMesh(PATH_JOIN(window->props.selfDir, RESOURCE_PATH::MODELS, "primitives"), "box.obj");
        meshes[mesh->GetMeshID()] = mesh;
    }
    {
        Mesh* mesh = new Mesh("sphere");
        mesh->LoadMesh(PATH_JOIN(window->props.selfDir, RESOURCE_PATH::MODELS, "primitives"), "sphere.obj");
        meshes[mesh->GetMeshID()] = mesh;
    }
    {
        Shader* shader = new Shader("TerrainShader");
        shader->AddShader(PATH_JOIN(window->props.selfDir, SOURCE_PATH::M1, "Tema2", "shaders", "VertexShader.glsl"), GL_VERTEX_SHADER);
        shader->AddShader(PATH_JOIN(window->props.selfDir, SOURCE_PATH::M1, "Tema2", "shaders", "FragmentShader.glsl"), GL_FRAGMENT_SHADER);
        shader->CreateAndLink();
        shaders[shader->GetName()] = shader;

    }

    {
        Mesh* cylinder = CreateCylinderMesh("cylinder", 0.5f, 2.0f, 32);
        meshes[cylinder->GetMeshID()] = cylinder;
    }

    {
        Mesh* cone = CreateConeMesh("cone", 0.8f, 2.0f, 32);
        meshes[cone->GetMeshID()] = cone;
    }
    {
        Mesh* ring = CreateRingMesh("ring", 2.5f, 3.0f, 64);
        meshes[ring->GetMeshID()] = ring;
    }
    meshes["rectangle"] = CreateRectangleMesh("rectangle", glm::vec3(0, 0, 1));
    meshes["triangle"] = CreateTriangleMesh("triangle", glm::vec3(0, 0, 1));
    GenerateTreePositions(30);
    GeneratePackagePosition();
    GenerateSnowmenPositions(5);
    GenerateCloudPositions(10);
    GenerateSnowflakes(100);
}

// generarea oamenilor de zapada
void Tema2::GenerateSnowmenPositions(int numberOfSnowmen) {
    snowmenPositions.clear();
    float minXZ = 4.0f;
    float maxXZ = 96.0f;
    float exclusionRadius = 10.0f;
    bool validPosition;

    for (int i = 0; i < numberOfSnowmen; i++) {
        glm::vec3 newSnowmanPosition;

        do {
            float randX = minXZ + static_cast<float>(rand()) / (RAND_MAX / (maxXZ - minXZ));
            float randZ = minXZ + static_cast<float>(rand()) / (RAND_MAX / (maxXZ - minXZ));

            float terrainHeight = GetTerrainHeight(randX, randZ);
            newSnowmanPosition = glm::vec3(randX, terrainHeight, randZ);

            validPosition = true;

            // distanta fata de drona
            if (glm::distance(newSnowmanPosition, glm::vec3(dronePosition.x, 0.0f, dronePosition.z)) < exclusionRadius) {
                validPosition = false;
                continue;
            }

            // distanta fata de pachet
            if (glm::distance(newSnowmanPosition, glm::vec3(packagePosition.x, 0.0f, packagePosition.z)) < exclusionRadius) {
                validPosition = false;
                continue;
            }

            // distanta fata de destinatie
            if (destinationVisible && glm::distance(newSnowmanPosition, glm::vec3(destinationPosition.x, 0.0f, destinationPosition.z)) < exclusionRadius) {
                validPosition = false;
                continue;
            }

            // cdistanta fata de copaci
            for (const auto& treePos : treePositions) {
                if (glm::distance(glm::vec2(newSnowmanPosition.x, newSnowmanPosition.z), glm::vec2(treePos.x, treePos.z)) < exclusionRadius) {
                    validPosition = false;
                    break;
                }
            }

            // distanta fata de oamenii de zapada
            for (const auto& snowmanPos : snowmenPositions) {
                if (glm::distance(glm::vec2(newSnowmanPosition.x, newSnowmanPosition.z), glm::vec2(snowmanPos.x, snowmanPos.z)) < exclusionRadius) {
                    validPosition = false;
                    break;
                }
            }

        } while (!validPosition);

        snowmenPositions.push_back(newSnowmanPosition);
    }

}

// generarea pozitiei pachetului
void Tema2::GeneratePackagePosition() {
    float minXZ = 2.0f;
    float maxXZ = 98.0f;
    glm::vec3 droneStartPosition = glm::vec3(50, 25, 10);
    float exclusionRadius = 10.0f;
    bool validPosition;

    do {
        float randX = minXZ + static_cast<float>(rand()) / (RAND_MAX / (maxXZ - minXZ));
        float randZ = minXZ + static_cast<float>(rand()) / (RAND_MAX / (maxXZ - minXZ));

        float terrainHeight = GetTerrainHeight(randX, randZ);
        packagePosition = glm::vec3(randX, terrainHeight + 3.0f, randZ);

        validPosition = true;

        // distanta fata de drona
        if (glm::distance(packagePosition, glm::vec3(droneStartPosition.x, 0.0f, droneStartPosition.z)) < exclusionRadius) {
            validPosition = false;
        }

        // distanta fata de copaci
        for (const auto& treePos : treePositions) {
            if (glm::distance(glm::vec2(packagePosition.x, packagePosition.z), glm::vec2(treePos.x, treePos.z)) < exclusionRadius) {
                validPosition = false;
                break;
            }
        }

        // distanta fata oamenii de zapada
        for (const auto& snowmanPos : snowmenPositions) {
            if (glm::distance(glm::vec2(packagePosition.x, packagePosition.z), glm::vec2(snowmanPos.x, snowmanPos.z)) < exclusionRadius) {
                validPosition = false;
                break;
            }
        }

    } while (!validPosition);

}

// generarea copacilor 
void Tema2::GenerateTreePositions(int numberOfTrees)
{
    treePositions.clear();
    float minXZ = 2.0f;
    float maxXZ = 98.0f;
    glm::vec3 droneStartPosition = glm::vec3(50, 25, 10);
    float exclusionRadius = 10.0f;

    for (int i = 0; i < numberOfTrees; i++) {
        float randX, randZ;
        glm::vec3 newTreePos;
        bool validPosition;

        do {
            randX = minXZ + static_cast<float>(rand()) / (RAND_MAX / (maxXZ - minXZ));
            randZ = minXZ + static_cast<float>(rand()) / (RAND_MAX / (maxXZ - minXZ));

            newTreePos = glm::vec3(randX, 0.0f, randZ);
            validPosition = true;

            // distanta fata de drona
            if (glm::distance(newTreePos, glm::vec3(droneStartPosition.x, 0.0f, droneStartPosition.z)) < exclusionRadius) {
                validPosition = false;
                continue;
            }

            // distanta fata de copaci
            for (const auto& treePos : treePositions) {
                if (glm::distance(newTreePos, treePos) < exclusionRadius) {
                    validPosition = false;
                    break;
                }
            }

            // distanta fata de pachet
            if (glm::distance(newTreePos, glm::vec3(packagePosition.x, 0.0f, packagePosition.z)) < exclusionRadius) {
                validPosition = false;
                continue;
            }

            // distanta fata de destinatie
            if (destinationVisible && glm::distance(newTreePos, glm::vec3(destinationPosition.x, 0.0f, destinationPosition.z)) < exclusionRadius) {
                validPosition = false;
                continue;
            }

        } while (!validPosition);

        treePositions.push_back(newTreePos);
    }
}

// generarea pozitiei destinatiei
void Tema2::GenerateDestinationPosition() {
    float minXZ = 4.0f;
    float maxXZ = 96.0f;
    float exclusionRadius = 10.0f;
    float treeAvoidanceRadius = 8.0f;
    bool validPosition;

    do {
        float randX = minXZ + static_cast<float>(rand()) / (RAND_MAX / (maxXZ - minXZ));
        float randZ = minXZ + static_cast<float>(rand()) / (RAND_MAX / (maxXZ - minXZ));

        float terrainHeight = GetTerrainHeight(randX, randZ);
        destinationPosition = glm::vec3(randX, terrainHeight + 0.8f, randZ);

        validPosition = true;

        // distanta fata de drona
        if (glm::distance(destinationPosition, glm::vec3(dronePosition.x, 0.0f, dronePosition.z)) < exclusionRadius) {
            validPosition = false;
            continue;
        }

        // distanta fata de pachet
        if (glm::distance(destinationPosition, glm::vec3(packagePosition.x, 0.0f, packagePosition.z)) < exclusionRadius) {
            validPosition = false;
            continue;
        }

        // distanta fata de copaci
        for (const auto& treePos : treePositions) {
            float distanceToTree = glm::distance(glm::vec2(destinationPosition.x, destinationPosition.z), glm::vec2(treePos.x, treePos.z));
            if (distanceToTree < treeAvoidanceRadius) {
                validPosition = false;
                break;
            }
        }

        // distanta fata de oamenii de zapada
        for (const auto& snowmanPos : snowmenPositions) {
            if (glm::distance(glm::vec2(destinationPosition.x, destinationPosition.z), glm::vec2(snowmanPos.x, snowmanPos.z)) < exclusionRadius) {
                validPosition = false;
                break;
            }
        }

    } while (!validPosition);

    destinationVisible = true;
}

// generarea norilor
void Tema2::GenerateCloudPositions(int numberOfClouds) {
    cloudPositions.clear();
    float minXZ = 4.0f;
    float maxXZ = 96.0f;
    float exclusionRadius = 15.0f;

    for (int i = 0; i < numberOfClouds; i++) {
        glm::vec3 newCloudPosition;
        bool validPosition;

        do {
            float randX = minXZ + static_cast<float>(rand()) / (RAND_MAX / (maxXZ - minXZ));
            float randZ = minXZ + static_cast<float>(rand()) / (RAND_MAX / (maxXZ - minXZ));

            float cloudHeight = 35.0f + static_cast<float>(rand()) / (RAND_MAX / 20.0f);
            newCloudPosition = glm::vec3(randX, cloudHeight, randZ);

            validPosition = true;

            // distanta fata de ceilalti nori
            for (const auto& existingCloud : cloudPositions) {
                if (glm::distance(glm::vec2(newCloudPosition.x, newCloudPosition.z),
                    glm::vec2(existingCloud.x, existingCloud.z)) < exclusionRadius) {
                    validPosition = false;
                    break;
                }
            }

        } while (!validPosition);

        cloudPositions.push_back(newCloudPosition);
    }
}

// generarea fulgilor de zapada
void Tema2::GenerateSnowflakes(int numberOfSnowflakes) {
    snowflakePositions.clear();

    float minXZ = 0.0f;
    float maxXZ = 100.0f;
    float minHeight = 50.0f;
    float maxHeight = 100.0f;

    for (int i = 0; i < numberOfSnowflakes; ++i) {
        float x = minXZ + static_cast<float>(rand()) / (RAND_MAX / (maxXZ - minXZ));
        float z = minXZ + static_cast<float>(rand()) / (RAND_MAX / (maxXZ - minXZ));
        float y = minHeight + static_cast<float>(rand()) / (RAND_MAX / (maxHeight - minHeight));

        snowflakePositions.push_back(glm::vec3(x, y, z));
    }
}

// functie pentru gestionarea coliziunii fulgilor cu obiectele din scena
void Tema2::UpdateSnowflakes(float deltaTime) {
    const float snowflakeFallSpeed = 5.0f;
    const float minXZ = 0.0f;
    const float maxXZ = 100.0f;
    const float maxHeight = 100.0f;

    std::vector<glm::vec3> updatedSnowflakes;

    for (const auto& snowflake : snowflakePositions) {
        glm::vec3 newPosition = snowflake - glm::vec3(0.0f, snowflakeFallSpeed * deltaTime, 0.0f);

        bool isColliding = false;

        // coliziunea cu terenul
        float terrainHeight = GetTerrainHeight(newPosition.x, newPosition.z);
        if (newPosition.y <= terrainHeight) {
            isColliding = true;
        }

        // coliziunea cu copacii
        for (const auto& treePos : treePositions) {
            float trunkRadius = 3.0f;
            float trunkHeight = 8.0f;
            if (IsCollidingWithCylinder(newPosition, treePos, trunkRadius, trunkHeight)) {
                isColliding = true;
                break;
            }
        }

        // coliziunea cu oamenii de zapada
        for (const auto& snowmanPos : snowmenPositions) {
            float snowmanRadius = 4.5f;
            float snowmanHeight = 7.5f;
            if (IsCollidingWithCylinder(newPosition, snowmanPos, snowmanRadius, snowmanHeight)) {
                isColliding = true;
                break;
            }
        }

        // coliziunea cu pachetul
        float packageRadius = 2.0f;
        if (glm::distance(newPosition, packagePosition) < packageRadius) {
            isColliding = true;
        }

        // coliziunea cu destinatia
        float destinationRadius = 2.0f;
        if (glm::distance(newPosition, destinationPosition) < destinationRadius) {
            isColliding = true;
        }

        // Verificăm coliziunea cu drona
        float droneRadius = 1.5f;
        if (glm::distance(newPosition, dronePosition) < droneRadius) {
            isColliding = true;
        }

        // daca fulgul nu este in coliziune si este deasupra terenului, pastram pozitia
        if (!isColliding && newPosition.y > terrainHeight) {
            updatedSnowflakes.push_back(newPosition);
        }
        else {
            // generarea de noi fulgi
            float newX = minXZ + static_cast<float>(rand()) / (RAND_MAX / (maxXZ - minXZ));
            float newZ = minXZ + static_cast<float>(rand()) / (RAND_MAX / (maxXZ - minXZ));
            float newY = maxHeight;
            updatedSnowflakes.push_back(glm::vec3(newX, newY, newZ));
        }
    }

    snowflakePositions = updatedSnowflakes;
}

// randarea fulgilor
void Tema2::RenderSnowflakes() {

    for (const auto& snowflake : snowflakePositions) {
        glm::mat4 modelMatrix = glm::mat4(1);
        modelMatrix = glm::translate(modelMatrix, snowflake);
        modelMatrix = glm::scale(modelMatrix, glm::vec3(0.5f));
        RenderMeshColor(meshes["sphere"], shaders["TerrainShader"], modelMatrix, glm::vec3(1.0f));
    }
}

// randarea destinatiei
void Tema2::RenderDestination() {
    if (!destinationVisible) return;

    glm::mat4 modelMatrix = glm::mat4(1);
    modelMatrix = glm::translate(modelMatrix, destinationPosition);
    modelMatrix = glm::scale(modelMatrix, glm::vec3(1.0f));
    RenderMeshColor(meshes["ring"], shaders["TerrainShader"], modelMatrix, glm::vec3(1.0f, 0.0f, 0.0f));
}

// mesh-ul pentru cilindru
Mesh* Tema2::CreateCylinderMesh(const std::string& meshName, float radius, float height, int segments)
{
    std::vector<VertexFormat> vertices;
    std::vector<unsigned int> indices;
    int startBottom = 0;
    int startTop = segments;
    int centerBottom = 2 * segments;
    int centerTop = 2 * segments + 1;

    for (int i = 0; i < segments; i++) {
        float theta = 2.0f * float(M_PI) * float(i) / float(segments);
        float x = radius * cos(theta);
        float z = radius * sin(theta);

        vertices.push_back(VertexFormat(
            glm::vec3(x, 0.0f, z),
            glm::vec3(1),
            glm::vec3(0, -1, 0)
        ));
    }
    for (int i = 0; i < segments; i++) {
        float theta = 2.0f * float(M_PI) * float(i) / float(segments);
        float x = radius * cos(theta);
        float z = radius * sin(theta);
        vertices.push_back(VertexFormat(
            glm::vec3(x, height, z),
            glm::vec3(1),
            glm::vec3(0, 1, 0)
        ));
    }
    vertices.push_back(VertexFormat(
        glm::vec3(0.0f, 0.0f, 0.0f),
        glm::vec3(1),
        glm::vec3(0, -1, 0)
    ));
    vertices.push_back(VertexFormat(
        glm::vec3(0.0f, height, 0.0f),
        glm::vec3(1),
        glm::vec3(0, 1, 0)
    ));
    for (int i = 0; i < segments; i++) {
        int next = (i + 1) % segments;
        indices.push_back(centerBottom);
        indices.push_back(startBottom + next);
        indices.push_back(startBottom + i);
    }

    for (int i = 0; i < segments; i++) {
        int next = (i + 1) % segments;
        indices.push_back(centerTop);
        indices.push_back(startTop + i);
        indices.push_back(startTop + next);
    }
    for (int i = 0; i < segments; i++) {
        int next = (i + 1) % segments;
        int v1 = startBottom + i;
        int v2 = startTop + i;
        int v3 = startTop + next;
        int v4 = startBottom + next;

        indices.push_back(v1);
        indices.push_back(v2);
        indices.push_back(v3);
        indices.push_back(v1);
        indices.push_back(v3);
        indices.push_back(v4);
    }
    Mesh* cylinder = new Mesh(meshName);
    cylinder->InitFromData(vertices, indices);
    return cylinder;
}

// mesh-ul pentru con
Mesh* Tema2::CreateConeMesh(const std::string& meshName, float radius, float height, int segments)
{
    std::vector<VertexFormat> vertices;
    std::vector<unsigned int> indices;

    for (int i = 0; i < segments; i++) {
        float theta = 2.0f * float(M_PI) * float(i) / float(segments);
        float x = radius * cos(theta);
        float z = radius * sin(theta);

        vertices.push_back(VertexFormat(
            glm::vec3(x, 0.0f, z),
            glm::vec3(1),
            glm::vec3(0, -1, 0)
        ));
    }
    int apexIndex = segments;
    vertices.push_back(VertexFormat(
        glm::vec3(0.0f, height, 0.0f),
        glm::vec3(1),
        glm::vec3(0, 1, 0)
    ));

    for (int i = 0; i < segments; i++) {
        int next = (i + 1) % segments;
        indices.push_back(i);
        indices.push_back(next);
        indices.push_back(apexIndex);
    }

    Mesh* cone = new Mesh(meshName);
    cone->InitFromData(vertices, indices);
    return cone;
}

// mesh ul pentru teren
Mesh* Tema2::CreateTerrainMesh(unsigned int numRows, unsigned int numCols, const std::string& meshName)
{
    vector<VertexFormat> vertices;
    vertices.reserve((numRows + 1) * (numCols + 1));

    vector<unsigned int> indices;
    indices.reserve(numRows * numCols * 6);

    for (unsigned int i = 0; i <= numRows; i++)
    {
        for (unsigned int j = 0; j <= numCols; j++)
        {
            float x = (float)j;
            float z = (float)i;
            float y = 0.0f;
            glm::vec3 normal = glm::vec3(0, 1, 0);
            glm::vec3 color = glm::vec3(0.2f, 0.8f, 0.2f);
            vertices.push_back(VertexFormat(glm::vec3(x, y, z), color, normal));
        }
    }

    for (unsigned int i = 0; i < numRows; i++)
    {
        for (unsigned int j = 0; j < numCols; j++)
        {
            unsigned int indexTopLeft = i * (numCols + 1) + j;
            unsigned int indexTopRight = i * (numCols + 1) + (j + 1);
            unsigned int indexBottomLeft = (i + 1) * (numCols + 1) + j;
            unsigned int indexBottomRight = (i + 1) * (numCols + 1) + (j + 1);

            indices.push_back(indexTopLeft);
            indices.push_back(indexBottomLeft);
            indices.push_back(indexTopRight);

            indices.push_back(indexTopRight);
            indices.push_back(indexBottomLeft);
            indices.push_back(indexBottomRight);
        }
    }
    Mesh* mesh = new Mesh(meshName);
    mesh->InitFromData(vertices, indices);
    return mesh;
}

// mesh ul pentru destinatie
Mesh* Tema2::CreateRingMesh(const std::string& meshName, float innerRadius, float outerRadius, int segments) {
    std::vector<VertexFormat> vertices;
    std::vector<unsigned int> indices;

    for (int i = 0; i < segments; ++i) {
        float theta = 2.0f * M_PI * i / segments;
        float nextTheta = 2.0f * M_PI * (i + 1) / segments;

        // cercul exterior
        vertices.emplace_back(glm::vec3(outerRadius * cos(theta), 0.0f, outerRadius * sin(theta)), glm::vec3(1));
        vertices.emplace_back(glm::vec3(outerRadius * cos(nextTheta), 0.0f, outerRadius * sin(nextTheta)), glm::vec3(1));

        // cercul interior
        vertices.emplace_back(glm::vec3(innerRadius * cos(theta), 0.0f, innerRadius * sin(theta)), glm::vec3(1));
        vertices.emplace_back(glm::vec3(innerRadius * cos(nextTheta), 0.0f, innerRadius * sin(nextTheta)), glm::vec3(1));

        indices.push_back(4 * i);
        indices.push_back(4 * i + 1);
        indices.push_back(4 * i + 2);

        indices.push_back(4 * i + 1);
        indices.push_back(4 * i + 3);
        indices.push_back(4 * i + 2);
    }

    Mesh* ring = new Mesh(meshName);
    ring->InitFromData(vertices, indices);
    return ring;
}

// mesh ul pentru rectangle
Mesh* Tema2::CreateRectangleMesh(const std::string& name, const glm::vec3& color) {
    std::vector<VertexFormat> vertices = {
        VertexFormat(glm::vec3(-0.1f, 0.0f, -0.4f), color),
        VertexFormat(glm::vec3(0.1f, 0.0f, -0.4f), color),
        VertexFormat(glm::vec3(0.1f, 0.0f, 0.4f), color),
        VertexFormat(glm::vec3(-0.1f, 0.0f, 0.4f), color)
    };

    std::vector<unsigned int> indices = { 0, 1, 2, 0, 2, 3 };

    Mesh* rectangle = new Mesh(name);
    rectangle->InitFromData(vertices, indices);
    return rectangle;
}

// mesh ul pentru triunghi
Mesh* Tema2::CreateTriangleMesh(const std::string& name, const glm::vec3& color) {
    std::vector<VertexFormat> vertices = {
        VertexFormat(glm::vec3(-0.2f, 0.0f, 0.4f), color),
        VertexFormat(glm::vec3(0.2f, 0.0f, 0.4f), color),
        VertexFormat(glm::vec3(0.0f, 0.0f, 0.8f), color)
    };

    std::vector<unsigned int> indices = { 0, 1, 2 };

    Mesh* triangle = new Mesh(name);
    triangle->InitFromData(vertices, indices);
    return triangle;
}

void Tema2::FrameStart()
{
    glClearColor(0.7f, 0.9f, 1.0f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    glm::ivec2 resolution = window->GetResolution();
    glViewport(0, 0, resolution.x, resolution.y);
}

void Tema2::RenderMeshColor(Mesh* mesh, Shader* shader, const glm::mat4& modelMatrix, const glm::vec3& color)
{
    if (!mesh || !shader || !shader->program)
        return;

    shader->Use();
    glUniformMatrix4fv(shader->loc_view_matrix, 1, GL_FALSE,
        glm::value_ptr(camera->GetViewMatrix()));
    glUniformMatrix4fv(shader->loc_projection_matrix, 1, GL_FALSE,
        glm::value_ptr(projectionMatrix));
    glUniformMatrix4fv(shader->loc_model_matrix, 1, GL_FALSE,
        glm::value_ptr(modelMatrix));

    GLint locIsTerrain = glGetUniformLocation(shader->program, "isTerrain");
    glUniform1i(locIsTerrain, 0);

    GLint locColor = glGetUniformLocation(shader->program, "objectColor");
    glUniform3fv(locColor, 1, glm::value_ptr(color));

    mesh->Render();
}

// randarea sagetii
void Tema2::RenderArrow(const glm::vec3& position, float yaw, const glm::vec3& color, bool isMinimap) {
    glm::mat4 modelMatrix = glm::mat4(1.0f);

    modelMatrix = glm::translate(modelMatrix, position);

    modelMatrix = glm::rotate(modelMatrix, yaw, glm::vec3(0, 1, 0));

    glm::vec3 rectScale = isMinimap ? glm::vec3(5.0f, 3.5f, 5.0f) : glm::vec3(1.0f, 0.7f, 1.0f);
    glm::vec3 triScale = isMinimap ? glm::vec3(8.0f, 2.0f, 8.0f) : glm::vec3(1.6f, 0.8f, 1.6f);

    glm::mat4 rectMatrix = modelMatrix;
    rectMatrix = glm::scale(rectMatrix, rectScale);
    RenderMeshColor(meshes["rectangle"], shaders["TerrainShader"], rectMatrix, color);

    glm::mat4 triMatrix = modelMatrix;
    triMatrix = glm::translate(triMatrix, glm::vec3(0.0f, 0.0f, isMinimap ? -2.0f : -0.4f));
    triMatrix = glm::scale(triMatrix, triScale);
    RenderMeshColor(meshes["triangle"], shaders["TerrainShader"], triMatrix, color);
}

// randarea minimap ului
void Tema2::RenderMinimap(float deltaTimeSeconds) {
    glm::mat4 originalProjectionMatrix = projectionMatrix;
    glm::vec3 originalCameraPosition = camera->GetPosition();
    glm::vec3 originalCameraTarget = camera->GetTargetPosition();
    glm::vec3 originalCameraUp = camera->GetUp();

    // viewport-ul pentru minimap
    glm::ivec2 resolution = window->GetResolution();
    int minimapWidth = 300;
    int minimapHeight = 200;
    glViewport(resolution.x - minimapWidth - 20, 20, minimapWidth, minimapHeight);

    glClear(GL_DEPTH_BUFFER_BIT);

    glm::vec3 minimapPosition = glm::vec3(50, 70, 50);
    glm::vec3 minimapTarget = glm::vec3(50, 0, 50);
    glm::vec3 minimapUp = glm::vec3(0, 0, -1);

    glm::mat4 rotationMatrix = glm::rotate(glm::mat4(1.0f), glm::radians(180.0f), glm::vec3(0, 1, 0));
    glm::vec4 rotatedForward = rotationMatrix * glm::vec4(minimapTarget - minimapPosition, 0.0f);
    glm::vec4 rotatedUp = rotationMatrix * glm::vec4(minimapUp, 0.0f);

    camera->Set(minimapPosition, minimapPosition + glm::vec3(rotatedForward), glm::vec3(rotatedUp));

    glm::mat4 orthoProjection = glm::ortho(-50.0f, 50.0f, -50.0f, 50.0f, 0.1f, 200.0f);
    projectionMatrix = orthoProjection;

    // terenul
    glm::mat4 modelMatrix = glm::mat4(1);
    RenderMesh(meshes["terrain"], shaders["TerrainShader"], modelMatrix, true);

    // copacii
    for (auto& treePos : treePositions) {
        glm::mat4 modelTrunk = glm::mat4(1);
        modelTrunk = glm::translate(modelTrunk, treePos);
        modelTrunk = glm::scale(modelTrunk, glm::vec3(1.2f, 8.0f, 1.2f));
        RenderMeshColor(meshes["cylinder"], shaders["TerrainShader"], modelTrunk, glm::vec3(0.4f, 0.2f, 0.0f));

        glm::mat4 modelCone = glm::mat4(1);
        modelCone = glm::translate(modelCone, treePos);
        modelCone = glm::translate(modelCone, glm::vec3(0, 8.0f, 0));
        modelCone = glm::scale(modelCone, glm::vec3(4.0f, 8.0f, 4.0f));
        RenderMeshColor(meshes["cone"], shaders["TerrainShader"], modelCone, glm::vec3(0.0f, 0.5f, 0.0f));
    }

    // pachetul
    if (!hasPackage) {
        glm::mat4 modelMatrix = glm::mat4(1);
        modelMatrix = glm::translate(modelMatrix, packagePosition);
        modelMatrix = glm::scale(modelMatrix, glm::vec3(3.0f));
        RenderMeshColor(meshes["box"], shaders["TerrainShader"], modelMatrix, glm::vec3(1.0f, 0.0f, 1.0f));
    }

    // destinatia
    if (destinationVisible) {
        glm::mat4 modelMatrix = glm::mat4(1);
        modelMatrix = glm::translate(modelMatrix, destinationPosition);
        modelMatrix = glm::scale(modelMatrix, glm::vec3(1.0f));
        RenderMeshColor(meshes["ring"], shaders["TerrainShader"], modelMatrix, glm::vec3(1.0f, 0.0f, 0.0f));
    }

    // oamenii de zapada
    for (const auto& snowmanPosition : snowmenPositions) {
        glm::mat4 modelMatrix = glm::mat4(1);
        modelMatrix = glm::translate(modelMatrix, snowmanPosition);
        modelMatrix = glm::scale(modelMatrix, glm::vec3(3.0f));
        RenderMeshColor(meshes["box"], shaders["TerrainShader"], modelMatrix, glm::vec3(1.0f, 0.5f, 0.0f));
    }

    // drona, reprezentata ca o sageata
    RenderArrow(dronePosition, droneYaw, glm::vec3(0.0f, 0.0f, 1.0f), true);

    // revenim la camera si proiectia originale
    camera->Set(originalCameraPosition, originalCameraTarget, originalCameraUp);
    projectionMatrix = originalProjectionMatrix;

    // resetam viewport-ul la ecranul principal
    glViewport(0, 0, resolution.x, resolution.y);
}

// randarea sagetii de directie in fata dronei
void Tema2::RenderArrowInFrontOfDrone() {
    float arrowDistanceFromDrone = 2.0f;

    glm::vec3 droneForward = glm::vec3(sin(droneYaw), 0.0f, cos(droneYaw));
    glm::vec3 arrowPosition = dronePosition + droneForward * arrowDistanceFromDrone;

    // directia catre tinta (pachet/destinatie)
    glm::vec3 targetPosition = hasPackage ? destinationPosition : packagePosition;
    glm::vec3 directionToTarget = glm::normalize(glm::vec3(targetPosition.x - arrowPosition.x, 0.0f, targetPosition.z - arrowPosition.z));
    float arrowYaw = atan2(directionToTarget.x, directionToTarget.z);

    RenderArrow(arrowPosition, arrowYaw, glm::vec3(0.0f, 0.0f, 1.0f), false);
}

void Tema2::Update(float deltaTimeSeconds)
{
    {
        glm::mat4 modelMatrix = glm::mat4(1);
        RenderMesh(meshes["terrain"], shaders["TerrainShader"], modelMatrix, true);
    }

    RenderArrowInFrontOfDrone();

    droneRotation = 8.0f;
    propellerAngle += deltaTimeSeconds * droneRotation;
    float armLength = 5.0f;
    float armThickness = 0.5f;
    float cubeSize = 0.5f;
    float bladeHeight = 0.1f;

    glm::vec3 colorArm(0.3f, 0.3f, 0.3f);
    glm::vec3 colorBlade(0.1f, 0.1f, 0.1f);

    float yCubeOffset = armThickness / 2.0f + (cubeSize / 2.0f);
    float yBladeOffset = (armThickness / 2.0f) + cubeSize + (bladeHeight / 2.0f);
    float rot45 = glm::radians(45.0f);

    // randarea dronei

    // bratul 1
    {
        glm::mat4 globalDrone = glm::mat4(1.0f);
        globalDrone = glm::translate(globalDrone, dronePosition);
        globalDrone = glm::rotate(globalDrone, droneYaw, glm::vec3(0, 1, 0));

        glm::mat4 armM = globalDrone;
        armM = glm::rotate(armM, rot45, glm::vec3(0, 1, 0));
        armM = glm::scale(armM, glm::vec3(armLength, armThickness, armThickness));
        RenderMeshColor(meshes["box"], shaders["TerrainShader"], armM, colorArm);
        {
            glm::mat4 cubeM = globalDrone;
            cubeM = glm::rotate(cubeM, rot45, glm::vec3(0, 1, 0));
            cubeM = glm::translate(cubeM, glm::vec3(armLength / 2.0f - (cubeSize / 2.0f), yCubeOffset, 0.0f));
            cubeM = glm::scale(cubeM, glm::vec3(cubeSize));
            RenderMeshColor(meshes["box"], shaders["TerrainShader"], cubeM, colorArm);

            glm::mat4 bladeM = globalDrone;
            bladeM = glm::rotate(bladeM, rot45, glm::vec3(0, 1, 0));
            bladeM = glm::translate(bladeM, glm::vec3(armLength / 2.0f - (cubeSize / 2.0f), yBladeOffset, 0.0f));
            bladeM = glm::rotate(bladeM, propellerAngle, glm::vec3(0, 1, 0));
            bladeM = glm::scale(bladeM, glm::vec3(2.0f, bladeHeight, 0.1f));
            RenderMeshColor(meshes["box"], shaders["TerrainShader"], bladeM, colorBlade);
        }

        {
            glm::mat4 cubeM = globalDrone;
            cubeM = glm::rotate(cubeM, rot45, glm::vec3(0, 1, 0));
            cubeM = glm::translate(cubeM, glm::vec3(-armLength / 2.0f + (cubeSize / 2.0f), yCubeOffset, 0.0f));
            cubeM = glm::scale(cubeM, glm::vec3(cubeSize));
            RenderMeshColor(meshes["box"], shaders["TerrainShader"], cubeM, colorArm);

            glm::mat4 bladeM = globalDrone;
            bladeM = glm::rotate(bladeM, rot45, glm::vec3(0, 1, 0));
            bladeM = glm::translate(bladeM, glm::vec3(-armLength / 2.0f + (cubeSize / 2.0f), yBladeOffset, 0.0f));
            bladeM = glm::rotate(bladeM, propellerAngle, glm::vec3(0, 1, 0));
            bladeM = glm::scale(bladeM, glm::vec3(2.0f, bladeHeight, 0.1f));
            RenderMeshColor(meshes["box"], shaders["TerrainShader"], bladeM, colorBlade);
        }
    }

    // bratul 2
    {
        glm::mat4 globalDrone = glm::mat4(1.0f);
        globalDrone = glm::translate(globalDrone, dronePosition);
        globalDrone = glm::rotate(globalDrone, droneYaw, glm::vec3(0, 1, 0));
        
        glm::mat4 armM = globalDrone;
        armM = glm::rotate(armM, -rot45, glm::vec3(0, 1, 0));
        armM = glm::scale(armM, glm::vec3(armLength, armThickness, armThickness));
        RenderMeshColor(meshes["box"], shaders["TerrainShader"], armM, colorArm);

        {
            glm::mat4 cubeM = globalDrone;
            cubeM = glm::rotate(cubeM, -rot45, glm::vec3(0, 1, 0));
            cubeM = glm::translate(cubeM, glm::vec3(armLength / 2.0f - (cubeSize / 2.0f), yCubeOffset, 0.0f));
            cubeM = glm::scale(cubeM, glm::vec3(cubeSize));
            RenderMeshColor(meshes["box"], shaders["TerrainShader"], cubeM, colorArm);

            glm::mat4 bladeM = globalDrone;
            bladeM = glm::rotate(bladeM, -rot45, glm::vec3(0, 1, 0));
            bladeM = glm::translate(bladeM, glm::vec3(armLength / 2.0f - (cubeSize / 2.0f), yBladeOffset, 0.0f));
            bladeM = glm::rotate(bladeM, propellerAngle, glm::vec3(0, 1, 0));
            bladeM = glm::scale(bladeM, glm::vec3(2.0f, bladeHeight, 0.1f));
            RenderMeshColor(meshes["box"], shaders["TerrainShader"], bladeM, colorBlade);
        }

        {
            glm::mat4 cubeM = globalDrone;
            cubeM = glm::rotate(cubeM, -rot45, glm::vec3(0, 1, 0));
            cubeM = glm::translate(cubeM, glm::vec3(-armLength / 2.0f + (cubeSize / 2.0f), yCubeOffset, 0.0f));
            cubeM = glm::scale(cubeM, glm::vec3(cubeSize));
            RenderMeshColor(meshes["box"], shaders["TerrainShader"], cubeM, colorArm);

            glm::mat4 bladeM = globalDrone;
            bladeM = glm::rotate(bladeM, -rot45, glm::vec3(0, 1, 0));
            bladeM = glm::translate(bladeM, glm::vec3(-armLength / 2.0f + (cubeSize / 2.0f), yBladeOffset, 0.0f));
            bladeM = glm::rotate(bladeM, propellerAngle, glm::vec3(0, 1, 0));
            bladeM = glm::scale(bladeM, glm::vec3(2.0f, bladeHeight, 0.1f));
            RenderMeshColor(meshes["box"], shaders["TerrainShader"], bladeM, colorBlade);
        }
    }

    // camera
    {
        float cosY = cos(droneYaw);
        float sinY = sin(droneYaw);
        glm::vec3 forwardDir = glm::vec3(sinY, 0, cosY);
        glm::vec3 upDir = glm::vec3(0, 1, 0);
        float distanceBack = 5.0f;
        float distanceUp = 3.0f;
        glm::vec3 cameraPos = dronePosition - distanceBack * forwardDir + glm::vec3(0, distanceUp, 0);
        glm::vec3 cameraTarget = dronePosition + glm::vec3(0, 1.0f, 0);

        camera->Set(cameraPos, cameraTarget, upDir);
    }

    // randarea copacilor
    {
        glm::vec3 trunkColor = glm::vec3(0.4f, 0.2f, 0.0f);
        glm::vec3 leavesColor = glm::vec3(0.0f, 0.5f, 0.0f);

        for (auto& pos : treePositions)
        {
            {
                glm::mat4 modelTrunk = glm::mat4(1);
                modelTrunk = glm::translate(modelTrunk, pos);
                modelTrunk = glm::scale(modelTrunk, glm::vec3(1.2f, 8.0f, 1.2f));
                RenderMeshColor(meshes["cylinder"], shaders["TerrainShader"], modelTrunk, trunkColor);
            }

            {
                glm::mat4 modelCone1 = glm::mat4(1);
                modelCone1 = glm::translate(modelCone1, pos);
                modelCone1 = glm::translate(modelCone1, glm::vec3(0, 8.0f, 0));
                modelCone1 = glm::scale(modelCone1, glm::vec3(4.0f, 8.0f, 4.0f));
                RenderMeshColor(meshes["cone"], shaders["TerrainShader"], modelCone1, leavesColor);
            }

            {
                glm::mat4 modelCone2 = glm::mat4(1);
                modelCone2 = glm::translate(modelCone2, pos);
                modelCone2 = glm::translate(modelCone2, glm::vec3(0, 14.0f, 0));
                modelCone2 = glm::scale(modelCone2, glm::vec3(3.2f, 6.4f, 3.2f));
                RenderMeshColor(meshes["cone"], shaders["TerrainShader"], modelCone2, leavesColor);
            }
        }
    }

    // randarea pachetului

    if (destinationVisible) {
        RenderDestination();
    }

    if (!hasPackage && !isPackageDropping) {
        glm::mat4 modelMatrix = glm::mat4(1);
        modelMatrix = glm::translate(modelMatrix, packagePosition);
        modelMatrix = glm::scale(modelMatrix, glm::vec3(3.0f));
        RenderMeshColor(meshes["box"], shaders["TerrainShader"], modelMatrix, glm::vec3(1.0f, 0.0f, 1.0f));
    }
    else if (hasPackage && !isPackageDropping) {
        // pachetul sub drona
        packagePosition = dronePosition - glm::vec3(0, 2.f, 0);
        glm::mat4 modelMatrix = glm::mat4(1);
        modelMatrix = glm::translate(modelMatrix, packagePosition);
        modelMatrix = glm::scale(modelMatrix, glm::vec3(2.0f));
        RenderMeshColor(meshes["box"], shaders["TerrainShader"], modelMatrix, glm::vec3(1.0f, 0.0f, 1.0f));
    }
    else if (isPackageDropping) {
        // pachetul cade
        glm::mat4 modelMatrix = glm::mat4(1);
        modelMatrix = glm::translate(modelMatrix, droppedPackagePosition);
        modelMatrix = glm::scale(modelMatrix, glm::vec3(3.0f));
        RenderMeshColor(meshes["box"], shaders["TerrainShader"], modelMatrix, glm::vec3(1.0f, 0.0f, 1.0f));
        destinationVisible = false;
        // simularea caderii pachetului
        droppedPackagePosition.y -= 5.0f * deltaTimeSeconds;
        float terrainHeight = GetTerrainHeight(droppedPackagePosition.x, droppedPackagePosition.z);
        if (droppedPackagePosition.y <= terrainHeight + 0.5f) {
            droppedPackagePosition.y = terrainHeight + 0.5f;
            isPackageDropping = false;
            GeneratePackagePosition();
        }
    }

    if (!hasPackage && glm::distance(dronePosition, packagePosition) < 3.0f) {
        hasPackage = true;
        GenerateDestinationPosition();
        destinationVisible = true;
    }

    // verificam daca pachetul este livrat
    if (hasPackage && glm::distance(glm::vec2(dronePosition.x, dronePosition.z), glm::vec2(destinationPosition.x, destinationPosition.z)) < 3.0f) {
        packagesCollected++;
        score += 5;
        std::cout << "Felicitari! Ai colectat " << packagesCollected << " pachete! Ai obtinut " << score << " puncte!" << std::endl;

        hasPackage = false;
        isPackageDropping = true;
        droppedPackagePosition = packagePosition;
        packagePosition = glm::vec3(0, -10, 0);
    }

    // randarea oamenilor de zapada
    glm::vec3 snowColor = glm::vec3(1.0f);
    glm::vec3 hatColor = glm::vec3(1.0f, 0.5f, 0.0f);
    glm::vec3 eyeColor = glm::vec3(0.0f);

    for (const auto& snowmanPosition : snowmenPositions) {
        // baza
        glm::mat4 modelMatrix = glm::mat4(1);
        modelMatrix = glm::translate(modelMatrix, snowmanPosition + glm::vec3(0.0f, 2.0f, 0.0f));
        modelMatrix = glm::scale(modelMatrix, glm::vec3(4.0f));
        RenderMeshColor(meshes["sphere"], shaders["TerrainShader"], modelMatrix, snowColor);

        // capul
        modelMatrix = glm::mat4(1);
        modelMatrix = glm::translate(modelMatrix, snowmanPosition + glm::vec3(0.0f, 4.5f, 0.0f));
        modelMatrix = glm::scale(modelMatrix, glm::vec3(2.5f));
        RenderMeshColor(meshes["sphere"], shaders["TerrainShader"], modelMatrix, snowColor);

        // ochii
        glm::vec3 eyeOffset1 = glm::vec3(-0.6f, 4.8f, 1.0f);
        glm::vec3 eyeOffset2 = glm::vec3(0.6f, 4.8f, 1.0f);

        modelMatrix = glm::mat4(1);
        modelMatrix = glm::translate(modelMatrix, snowmanPosition + eyeOffset1);
        modelMatrix = glm::scale(modelMatrix, glm::vec3(0.3f));
        RenderMeshColor(meshes["sphere"], shaders["TerrainShader"], modelMatrix, eyeColor);

        modelMatrix = glm::mat4(1);
        modelMatrix = glm::translate(modelMatrix, snowmanPosition + eyeOffset2);
        modelMatrix = glm::scale(modelMatrix, glm::vec3(0.3f));
        RenderMeshColor(meshes["sphere"], shaders["TerrainShader"], modelMatrix, eyeColor);

        // baza palariei
        glm::vec3 hatBaseOffset = glm::vec3(0.0f, 5.5f, 0.0f);
        modelMatrix = glm::mat4(1);
        modelMatrix = glm::translate(modelMatrix, snowmanPosition + hatBaseOffset);
        modelMatrix = glm::scale(modelMatrix, glm::vec3(3.0f, 0.5f, 3.0f));
        RenderMeshColor(meshes["box"], shaders["TerrainShader"], modelMatrix, hatColor);

        // palaria
        glm::vec3 hatTopOffset = glm::vec3(0.0f, 6.1f, 0.0f);
        modelMatrix = glm::mat4(1);
        modelMatrix = glm::translate(modelMatrix, snowmanPosition + hatTopOffset);
        modelMatrix = glm::scale(modelMatrix, glm::vec3(2.0f, 1.0f, 2.0f));
        RenderMeshColor(meshes["box"], shaders["TerrainShader"], modelMatrix, hatColor);
    }

    // randarea norilor

    glm::vec3 cloudColor = glm::vec3(0.8f);
    for (const auto& cloudPosition : cloudPositions) {
        // sfera de sus
        glm::mat4 modelMatrix = glm::mat4(1);
        modelMatrix = glm::translate(modelMatrix, cloudPosition + glm::vec3(0.0f, 2.0f, 0.0f));
        modelMatrix = glm::scale(modelMatrix, glm::vec3(6.0f, 4.0f, 6.0f));
        RenderMeshColor(meshes["sphere"], shaders["TerrainShader"], modelMatrix, cloudColor);

        // sfera din stanga
        modelMatrix = glm::mat4(1);
        modelMatrix = glm::translate(modelMatrix, cloudPosition + glm::vec3(-4.0f, 0.0f, 0.0f));
        modelMatrix = glm::scale(modelMatrix, glm::vec3(8.5f, 4.0f, 8.5f));
        RenderMeshColor(meshes["sphere"], shaders["TerrainShader"], modelMatrix, cloudColor);

        // sfera din dreapta
        modelMatrix = glm::mat4(1);
        modelMatrix = glm::translate(modelMatrix, cloudPosition + glm::vec3(4.0f, 0.0f, 0.0f));
        modelMatrix = glm::scale(modelMatrix, glm::vec3(8.5f, 4.0f, 8.5f));
        RenderMeshColor(meshes["sphere"], shaders["TerrainShader"], modelMatrix, cloudColor);
    }

    // actualizarea fulgilor
    UpdateSnowflakes(deltaTimeSeconds);

    // randarea fulgilor
    RenderSnowflakes();

    // randarea minimap ului
    RenderMinimap(deltaTimeSeconds);
}

// verificarea coliziunii cu cilindrul
bool Tema2::IsCollidingWithCylinder(const glm::vec3& dronePos, const glm::vec3& cylinderBase, float cylinderRadius, float cylinderHeight) {
    glm::vec2 droneXZ(dronePos.x, dronePos.z);
    glm::vec2 cylinderXZ(cylinderBase.x, cylinderBase.z);
    float distanceXZ = glm::length(droneXZ - cylinderXZ);
    if (distanceXZ > cylinderRadius) return false;
    if (dronePos.y < cylinderBase.y || dronePos.y > cylinderBase.y + cylinderHeight) return false;
    return true;
}

// verificarea coliziunii cu sfera
bool Tema2::IsCollidingWithSphere(const glm::vec3& dronePos, const glm::vec3& sphereCenter, float sphereRadius) {
    float distance = glm::length(dronePos - sphereCenter);
    return distance <= sphereRadius;
}

void Tema2::FrameEnd()
{}

void Tema2::RenderMesh(Mesh* mesh, Shader* shader, const glm::mat4& modelMatrix, bool isTerrain)
{
    if (!mesh || !shader || !shader->program)
        return;

    shader->Use();

    glUniformMatrix4fv(shader->loc_view_matrix, 1, GL_FALSE,
        glm::value_ptr(camera->GetViewMatrix()));
    glUniformMatrix4fv(shader->loc_projection_matrix, 1, GL_FALSE,
        glm::value_ptr(projectionMatrix));
    glUniformMatrix4fv(shader->loc_model_matrix, 1, GL_FALSE,
        glm::value_ptr(modelMatrix));

    GLint locIsTerrain = glGetUniformLocation(shader->program, "isTerrain");
    glUniform1i(locIsTerrain, isTerrain ? 1 : 0);
    if (!isTerrain) {
        GLint locDronePos = glGetUniformLocation(shader->program, "dronePos");
        glUniform3fv(locDronePos, 1, glm::value_ptr(dronePosition));

        GLint locTreeBasePos = glGetUniformLocation(shader->program, "treeBasePos");
        glUniform3fv(locTreeBasePos, 1, glm::value_ptr(treeBasePos));
    }
    mesh->Render();
}

float Tema2::random2D(const glm::vec2& st)
{
    float dotValue = glm::dot(st, glm::vec2(12.9898f, 78.233f));
    float c = sin(dotValue) * 43758.5453f;
    return c - floor(c);
}

float Tema2::noise2D(const glm::vec2& st)
{
    glm::vec2 i = glm::floor(st);
    glm::vec2 f = glm::fract(st);

    float a = random2D(i);
    float b = random2D(i + glm::vec2(1.0, 0.0));
    float c = random2D(i + glm::vec2(0.0, 1.0));
    float d = random2D(i + glm::vec2(1.0, 1.0));

    glm::vec2 u = f * f * (3.0f - 2.0f * f);

    return glm::mix(a, b, u.x)
        + (c - a) * u.y * (1.0f - u.x)
        + (d - b) * u.x * u.y;
}

// inaltimea terenului
float Tema2::GetTerrainHeight(float x, float z) {
    float freq = 0.1f;
    float amplitude = 2.0f;
    float n = noise2D(glm::vec2(x, z) * freq);
    return n * amplitude;
}

void Tema2::OnInputUpdate(float deltaTime, int mods)
{
    float speed = movementSpeed * deltaTime;
    glm::vec3 initialPosition = dronePosition;

    float cosY = cos(droneYaw);
    float sinY = sin(droneYaw);

    glm::vec3 forwardDir = glm::vec3(sinY, 0, cosY);
    glm::vec3 rightDir = glm::vec3(cosY, 0, -sinY);
    glm::vec3 upDir = glm::vec3(0, 1, 0);

    if (window->KeyHold(GLFW_KEY_W)) {
        dronePosition += forwardDir * speed;
    }
    if (window->KeyHold(GLFW_KEY_S)) {
        dronePosition -= forwardDir * speed;
    }
    if (window->KeyHold(GLFW_KEY_A)) {
        dronePosition += rightDir * speed;
    }
    if (window->KeyHold(GLFW_KEY_D)) {
        dronePosition -= rightDir * speed;
    }
    if (window->KeyHold(GLFW_KEY_Q)) {
        dronePosition -= upDir * speed;
    }
    if (window->KeyHold(GLFW_KEY_E)) {
        dronePosition += upDir * speed;
    }

    float rotSpd = rotationSpeed * deltaTime;
    if (window->KeyHold(GLFW_KEY_Z)) {
        droneYaw += rotSpd;
    }
    if (window->KeyHold(GLFW_KEY_X)) {
        droneYaw -= rotSpd;
    }

    float terrainHeight = GetTerrainHeight(dronePosition.x, dronePosition.z);
    const float droneRadius = 1.0f;
    const float packageOffset = 2.0f; 

    if (hasPackage) {
        float packageHeight = terrainHeight + droneRadius + packageOffset;
        if (dronePosition.y <= packageHeight) {
            dronePosition.y = packageHeight;
        }
    }
    else {
        if (dronePosition.y < terrainHeight + droneRadius) {
            dronePosition.y = terrainHeight + droneRadius;
        }
    }

    // coliziunea cu copacii
    for (const auto& treePos : treePositions) {
        float trunkHeight = 8.0f;
        float trunkRadius = 3.0f;
        glm::vec3 trunkMin = treePos;
        glm::vec3 trunkMax = treePos + glm::vec3(0, trunkHeight, 0);

        if (dronePosition.y >= trunkMin.y && dronePosition.y <= trunkMax.y) {
            float distXZ = glm::distance(glm::vec2(dronePosition.x, dronePosition.z), glm::vec2(treePos.x, treePos.z));
            if (distXZ < trunkRadius) {
                dronePosition = initialPosition;
                continue;
            }
        }

        float coneHeight = 20.0f;
        float coneBaseRadius = 6.0f;
        glm::vec3 coneBase = treePos + glm::vec3(0, trunkHeight - 1.0f, 0);

        if (dronePosition.y >= coneBase.y && dronePosition.y <= coneBase.y + coneHeight) {
            float distXZ = glm::distance(glm::vec2(dronePosition.x, dronePosition.z), glm::vec2(coneBase.x, coneBase.z));
            if (distXZ < coneBaseRadius) {
                dronePosition = initialPosition;
                continue;
            }
        }
    }

    // coliziunea cu terenul
    if (dronePosition.y < terrainHeight + droneRadius) {
        dronePosition.y = terrainHeight + droneRadius;
    }

    // coliziunea cu pachetul
    float packageRadius = 2.0f;
    if (glm::distance(dronePosition, packagePosition) < packageRadius) {
        GeneratePackagePosition();
    }

    // coliziunea cu oamenii de zapada
    for (const auto& snowmanPosition : snowmenPositions) {
        float snowmanRadius = 4.5f;
        float snowmanHeight = 7.5f;
        glm::vec3 snowmanBase = snowmanPosition + glm::vec3(0, 0.0f, 0);

        if (IsCollidingWithCylinder(dronePosition, snowmanBase, snowmanRadius, snowmanHeight)) {
            dronePosition = initialPosition;
            break;
        }

        if (hasPackage) {
            glm::vec3 packagePositionUnderDrone = dronePosition - glm::vec3(0, 2.0f, 0);
            if (IsCollidingWithCylinder(packagePositionUnderDrone, snowmanBase, snowmanRadius, snowmanHeight)) {
                dronePosition = initialPosition;
                break;
            }
        }
    }

    // coliziunea cu norii
    for (const auto& cloudPosition : cloudPositions) {
        float centralSphereRadius = 5.0f;
        glm::vec3 centralSphereCenter = cloudPosition + glm::vec3(0, 2.0f, 0);

        if (IsCollidingWithSphere(dronePosition, centralSphereCenter, centralSphereRadius)) {
            dronePosition = initialPosition;
            break;
        }

        float sideSphereRadius = 5.0f;
        glm::vec3 leftSphereCenter = cloudPosition + glm::vec3(-4.5f, 0.0f, 0);
        glm::vec3 rightSphereCenter = cloudPosition + glm::vec3(4.5f, 0.0f, 0);

        if (IsCollidingWithSphere(dronePosition, leftSphereCenter, sideSphereRadius) ||
            IsCollidingWithSphere(dronePosition, rightSphereCenter, sideSphereRadius)) {
            dronePosition = initialPosition;
            break;
        }
    }
}

void Tema2::OnKeyPress(int key, int mods)
{
    if (key == GLFW_KEY_T)
    {
        renderCameraTarget = !renderCameraTarget;
    }
}

void Tema2::OnKeyRelease(int key, int mods)
{}
void Tema2::OnMouseMove(int mouseX, int mouseY, int deltaX, int deltaY)
{}
void Tema2::OnMouseBtnPress(int mouseX, int mouseY, int button, int mods)
{}
void Tema2::OnMouseBtnRelease(int mouseX, int mouseY, int button, int mods)
{}
void Tema2::OnMouseScroll(int mouseX, int mouseY, int offsetX, int offsetY)
{}
void Tema2::OnWindowResize(int width, int height)
{}
