﻿#include "lab_m1/Tema1/Tema1.h"
#include <vector>
#include <iostream>
#include <cmath>
#include "lab_m1/Tema1/transform2D.h"
#include "lab_m1/Tema1/object2D.h"

using namespace std;
using namespace m1;

Tema1::Tema1() {
    gravity = 2000.0f;
    projectileSpeed = 1000.0f;
    tankHealth = 100.0f;
    secondTankHealth = 100.0f;
    showFirstTank = true;
    showSecondTank = true;

}

Tema1::~Tema1() {}

void Tema1::FrameStart() {
    glClearColor(skyColor.r, skyColor.g, skyColor.b, 1);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    glm::ivec2 resolution = window->GetResolution();
    glViewport(0, 0, resolution.x, resolution.y);
}

void Tema1::Init() {
    glm::ivec2 resolution = window->GetResolution();
    auto camera = GetSceneCamera();
    camera->SetOrthographic(0, (float)resolution.x, 0, (float)resolution.y, 0.01f, 400);
    camera->SetPosition(glm::vec3(0, 0, 50));
    camera->SetRotation(glm::vec3(0, 0, 0));
    camera->Update();
    GetCameraInput()->SetActive(false);

    groundColor = glm::vec3(1.0f, 0.75f, 0.8f);
    skyColor = glm::vec3(0.8f, 0.9f, 1.0f);

    tankPosition = glm::vec2(85, 200);
    tankSpeed = 50.0f;
    turretRotationAngle = 0.0f;

    secondTankPosition = glm::vec2(resolution.x - 85, 200);
    secondTurretRotationAngle = 0.0f;

    int numPoints = 1000;
    float width = (float)resolution.x;

    heightMap.clear();
    for (int i = 0; i <= numPoints; i++) {
        float x = (float)i / numPoints * width;
        float y = 250 + 70 * sin(0.2f * x * 0.05f) + 60 * sin(0.5f * x * 0.05f) + 40 * sin(0.2f * x * 0.05f);
        heightMap.push_back(glm::vec2(x, y));
    }

    UpdateTerrainMeshes();

    meshes["tank_base1"] = object2D::CreateTrapezoid("tank_base1", glm::vec3(0, 0, 0), 30, 50, 10, glm::vec3(0.54f, 0, 0.54f), true);
    meshes["tank_base2"] = object2D::CreateTrapezoid("tank_base2", glm::vec3(0, 10, 0), 65, 40, 15, glm::vec3(0, 0, 0.5f), true);
    meshes["tank_turret"] = object2D::CreateArc("tank_turret", glm::vec3(0, 25, 0), 15, 0, (float)M_PI, glm::vec3(0.54f, 0, 0.54f));
    meshes["tank_gun"] = object2D::CreateRectangle("tank_gun", glm::vec3(-5.0f, 38, 0), 10, 20, glm::vec3(0, 0, 0.5f), true);

    meshes["second_tank_base1"] = object2D::CreateTrapezoid("second_tank_base1", glm::vec3(0, 0, 0), 30, 50, 10, glm::vec3(0, 0.39f, 0), true);
    meshes["second_tank_base2"] = object2D::CreateTrapezoid("second_tank_base2", glm::vec3(0, 10, 0), 65, 40, 15, glm::vec3(1, 1, 0), true);
    meshes["second_tank_turret"] = object2D::CreateArc("second_tank_turret", glm::vec3(0, 25, 0), 15, 0, (float)M_PI, glm::vec3(0, 0.39f, 0));
    meshes["second_tank_gun"] = object2D::CreateRectangle("second_tank_gun", glm::vec3(-5.0f, 38, 0), 10, 20, glm::vec3(1, 1, 0), true);

    meshes["projectile"] = object2D::CreateCircle("projectile", glm::vec3(0, 0, 0), 5, glm::vec3(0, 0, 0), true);
}

void Tema1::DrawHealthBar(const glm::vec2& position, float health) {
    float barWidth = 60.0f;
    float barHeight = 10.0f;
    float healthRatio = health / 100.0f;
    glm::vec3 fillColor = glm::vec3(1 - healthRatio, healthRatio, 0);

    glm::mat3 barModelMatrix = glm::mat3(1);
    barModelMatrix *= transform2D::Translate(position.x - barWidth / 2, position.y + 40.0f);
    RenderMesh2D(object2D::CreateRectangle("health_fill", glm::vec3(0, 0, 0), barWidth * healthRatio, barHeight, fillColor, true), shaders["VertexColor"], barModelMatrix);
}

bool Tema1::CheckCollisionWithTank(const glm::vec2& projectilePos, glm::vec2& tankPosition, float& tankHealth, bool& tankVisible) {
    float distance = glm::distance(projectilePos, tankPosition - glm::vec2(15, 0));
    if (distance < tankRadius + projectileRadius) {
        tankHealth -= 20.0f;
        if (tankHealth <= 0.0f) {
            tankVisible = false;
        }
        return true;
    }
    return false;
}


void Tema1::SimulateLandslide(float deltaTime, glm::vec2 start, glm::vec2 final) {
    start.x -= 10;
    final.x += 10;

    if (!terrainModified) return;

    int numPoints = 1000;
    int indStart = (float)start.x / (float)window->GetResolution().x * numPoints;
    int indFinal = (float)final.x / (float)window->GetResolution().x * numPoints;

    if (indStart == 0) indStart++;
    if (indFinal == heightMap.size() - 1) indFinal--;

    for (int i = indStart; i < indFinal; ++i) {
        glm::vec2& P1 = heightMap[i - 1];
        glm::vec2& P2 = heightMap[i];
        glm::vec2& P3 = heightMap[i + 1];

        P2.y = (P1.y + P2.y + P3.y) / 3.0f;
    }

    terrainTime += 1;
    if (terrainTime > 10) terrainModified = false;
    UpdateTerrainMeshes();
}

void Tema1::UpdateTankYPosition(float deltaTime, glm::vec2& position, float& rotationAngle) {
    for (int i = 0; i < heightMap.size() - 1; ++i) {
        glm::vec2& A = heightMap[i];
        glm::vec2& B = heightMap[i + 1];

        if (position.x >= A.x && position.x <= B.x) {
            float t = (position.x - A.x) / (B.x - A.x);
            float targetY = A.y * (1 - t) + B.y * t - 5.0f;
            position.y = targetY + 5.0f;

            float slope = (B.y - A.y) / (B.x - A.x);
            rotationAngle = atan(slope);
            break;
        }
    }
}

void Tema1::LaunchProjectile(std::vector<Projectile>& projectiles, const glm::vec2& tankPosition, float tankRotationAngle, float turretAngle) {
    Projectile proj;

    glm::mat3 tankModelMatrix = glm::mat3(1);
    tankModelMatrix *= transform2D::Translate(tankPosition.x, tankPosition.y);
    tankModelMatrix *= transform2D::Rotate(tankRotationAngle);

    glm::mat3 turretModelMatrix = tankModelMatrix;
    turretModelMatrix *= transform2D::Translate(0, 30.0f);
    turretModelMatrix *= transform2D::Rotate(turretAngle);

    glm::vec2 barrelTipLocal = glm::vec2(0, 75);
    glm::vec2 barrelTipGlobal = turretModelMatrix * glm::vec3(barrelTipLocal, 1);

    proj.position = barrelTipGlobal;
    float totalRotationAngle = tankRotationAngle + turretAngle + M_PI / 2;
    proj.velocity = glm::vec2(cos(totalRotationAngle), sin(totalRotationAngle)) * projectileSpeed;

    projectiles.push_back(proj);
}

void Tema1::UpdateProjectile(std::vector<Projectile>& projectiles, float deltaTime) {
    for (int i = projectiles.size() - 1; i >= 0; i--) {
        Projectile& proj = projectiles[i];
        proj.position += proj.velocity * deltaTime;
        proj.velocity.y -= gravity * deltaTime;

        if (CheckCollisionWithTank(proj.position, tankPosition, tankHealth, showFirstTank) ||
            CheckCollisionWithTank(proj.position, secondTankPosition, secondTankHealth, showSecondTank)) {
            projectiles.erase(projectiles.begin() + i);
            continue;
        }

        if (CheckCollisionAndDeformTerrain(proj.position, deltaTime)) {
            projectiles.erase(projectiles.begin() + i);
            continue;
        }

        if (proj.position.y <= 0 || proj.position.x < 0 || proj.position.x > window->GetResolution().x) {
            projectiles.erase(projectiles.begin() + i);
        }
    }
}

bool Tema1::CheckCollisionAndDeformTerrain(const glm::vec2& projectilePos, float deltaTime) {
    for (int i = 0; i < heightMap.size() - 1; ++i) {
        glm::vec2& P1 = heightMap[i];
        glm::vec2& P2 = heightMap[i + 1];

        if (projectilePos.x >= P1.x && projectilePos.x <= P2.x) {
            float t = (projectilePos.x - P1.x) / (P2.x - P1.x);
            float terrainY = P1.y * (1 - t) + P2.y * t;

            if (fabs(projectilePos.y - terrainY) < collisionDistance) {
                DeformTerrain(projectilePos.x, projectilePos.y, explosionRadius, deltaTime);
                return true;
            }
        }
    }
    return false;
}


void Tema1::DeformTerrain(float impactX, float impactY, float radius, float deltaTime) {
    start = glm::vec2(-1), final = glm::vec2(-1);

    for (int i = 0; i < heightMap.size(); ++i) {
        glm::vec2& point = heightMap[i];
        float distance = glm::distance(point, glm::vec2(impactX, impactY));

        if (distance < radius) {
            float dropAmount = sqrt(radius * radius - distance * distance);
            point.y -= dropAmount;
            if (start.y == -1) start = point;

            final = point;
            terrainModified = true;
            terrainTime = 0;
        }
    }

    UpdateTerrainMeshes();
}


void Tema1::UpdateTerrainMeshes() {
    terrainMeshes.clear();

    for (int i = 0; i < heightMap.size() - 1; i++) {
        glm::vec2& p1 = heightMap[i];
        glm::vec2& p2 = heightMap[i + 1];
        glm::vec2 p3(p2.x, 0);
        glm::vec2 p4(p1.x, 0);

        vector<VertexFormat> vertices = {
            VertexFormat(glm::vec3(p1, 0), groundColor),
            VertexFormat(glm::vec3(p2, 0), groundColor),
            VertexFormat(glm::vec3(p3, 0), groundColor),
            VertexFormat(glm::vec3(p4, 0), groundColor)
        };

        vector<unsigned int> indices = { 0, 1, 2, 0, 2, 3 };

        Mesh* terrainSegment = new Mesh("terrainSegment_" + std::to_string(i));
        terrainSegment->InitFromData(vertices, indices);
        terrainMeshes.push_back(terrainSegment);
    }
}

void Tema1::DrawTrajectory(const glm::vec2& position, float tankRotationAngle, float turretAngle, const glm::vec3& color) {
    glm::mat3 tankModelMatrix = glm::mat3(1);
    tankModelMatrix *= transform2D::Translate(position.x, position.y);
    tankModelMatrix *= transform2D::Rotate(tankRotationAngle);

    glm::mat3 turretModelMatrix = tankModelMatrix;
    turretModelMatrix *= transform2D::Translate(0, 20.0f);
    turretModelMatrix *= transform2D::Rotate(turretAngle);

    glm::vec2 barrelTipLocal(0, 35);
    glm::vec2 startPoint = turretModelMatrix * glm::vec3(barrelTipLocal, 1);

    glm::vec2 velocity = glm::vec2(cos(tankRotationAngle + turretAngle + M_PI / 2), sin(tankRotationAngle + turretAngle + M_PI / 2)) * projectileSpeed;

    const float timeStep = 0.1f;
    glm::vec2 currentPosition = startPoint;
    glm::vec2 currentVelocity = velocity;

    for (int i = 0; i < 100; i++) {
        glm::vec2 nextPosition = currentPosition + currentVelocity * timeStep;
        currentVelocity.y -= gravity * timeStep;

        bool intersectsTerrain = false;
        for (int j = 0; j < heightMap.size() - 1; j++) {
            glm::vec2& P1 = heightMap[j];
            glm::vec2& P2 = heightMap[j + 1];

            float t = (nextPosition.x - P1.x) / (P2.x - P1.x);
            if (t >= 0.0f && t <= 1.0f) {
                float terrainY = P1.y * (1 - t) + P2.y * t;
                if (nextPosition.y <= terrainY) {
                    intersectsTerrain = true;
                    break;
                }
            }
        }

        if (intersectsTerrain) {
            RenderMesh2D(object2D::CreateLine("trajectory_segment_" + to_string(i), currentPosition, nextPosition, color), shaders["VertexColor"], glm::mat3(1));
            break;
        }

        RenderMesh2D(object2D::CreateLine("trajectory_segment_" + to_string(i), currentPosition, nextPosition, color), shaders["VertexColor"], glm::mat3(1));

        currentPosition = nextPosition;

        if (currentPosition.y <= 0 || currentPosition.x < 0 || currentPosition.x > window->GetResolution().x) {
            break;
        }
    }
}

void Tema1::Update(float deltaTimeSeconds) {
    SimulateLandslide(deltaTimeSeconds, start, final);

    for (Mesh* terrainSegment : terrainMeshes) {
        RenderMesh2D(terrainSegment, shaders["VertexColor"], glm::mat3(1));
    }

    if (showFirstTank) {
        UpdateTankYPosition(deltaTimeSeconds, tankPosition, tankRotationAngle);
        glm::mat3 tankModelMatrix = glm::mat3(1);
        tankModelMatrix *= transform2D::Translate(tankPosition.x, tankPosition.y);
        tankModelMatrix *= transform2D::Rotate(tankRotationAngle);
        RenderMesh2D(meshes["tank_base1"], shaders["VertexColor"], tankModelMatrix);
        RenderMesh2D(meshes["tank_base2"], shaders["VertexColor"], tankModelMatrix);
        RenderMesh2D(meshes["tank_turret"], shaders["VertexColor"], tankModelMatrix);
        DrawHealthBar(tankPosition, tankHealth);

        glm::mat3 gunModelMatrix = tankModelMatrix;
        gunModelMatrix *= transform2D::Translate(0, 25);
        gunModelMatrix *= transform2D::Rotate(turretRotationAngle);
        gunModelMatrix *= transform2D::Translate(0, -25);
        RenderMesh2D(meshes["tank_gun"], shaders["VertexColor"], gunModelMatrix);
        DrawTrajectory(tankPosition, tankRotationAngle, turretRotationAngle, glm::vec3(1, 0, 1));
        UpdateProjectile(tankProjectiles, deltaTimeSeconds);
        for (const auto& proj : tankProjectiles) {
            glm::mat3 projectileMatrix = glm::mat3(1);
            projectileMatrix *= transform2D::Translate(proj.position.x, proj.position.y);
            RenderMesh2D(meshes["projectile"], shaders["VertexColor"], projectileMatrix);
        }
    }

    if (showSecondTank) {
        UpdateTankYPosition(deltaTimeSeconds, secondTankPosition, secondTankRotationAngle);
        glm::mat3 secondTankModelMatrix = glm::mat3(1);
        secondTankModelMatrix *= transform2D::Translate(secondTankPosition.x, secondTankPosition.y);
        secondTankModelMatrix *= transform2D::Rotate(secondTankRotationAngle);
        RenderMesh2D(meshes["second_tank_base1"], shaders["VertexColor"], secondTankModelMatrix);
        RenderMesh2D(meshes["second_tank_base2"], shaders["VertexColor"], secondTankModelMatrix);
        RenderMesh2D(meshes["second_tank_turret"], shaders["VertexColor"], secondTankModelMatrix);
        DrawHealthBar(secondTankPosition, secondTankHealth);

        glm::mat3 secondGunModelMatrix = secondTankModelMatrix;
        secondGunModelMatrix *= transform2D::Translate(0, 25);
        secondGunModelMatrix *= transform2D::Rotate(secondTurretRotationAngle);
        secondGunModelMatrix *= transform2D::Translate(0, -25);
        RenderMesh2D(meshes["second_tank_gun"], shaders["VertexColor"], secondGunModelMatrix);
        DrawTrajectory(secondTankPosition, secondTankRotationAngle, secondTurretRotationAngle, glm::vec3(1, 0, 1));
        UpdateProjectile(secondTankProjectiles, deltaTimeSeconds);
        for (const auto& proj : secondTankProjectiles) {
            glm::mat3 projectileMatrix = glm::mat3(1);
            projectileMatrix *= transform2D::Translate(proj.position.x, proj.position.y);
            RenderMesh2D(meshes["projectile"], shaders["VertexColor"], projectileMatrix);
        }
    }

}
void Tema1::FrameEnd() {}

void Tema1::OnInputUpdate(float deltaTime, int mods) {
    if (window->KeyHold(GLFW_KEY_LEFT)) {
        secondTankPosition.x -= tankSpeed * deltaTime;

        if (secondTankPosition.x < 0) secondTankPosition.x = 0;
    }
    if (window->KeyHold(GLFW_KEY_RIGHT)) {
        secondTankPosition.x += tankSpeed * deltaTime;

        if (secondTankPosition.x > windowResolution.x) secondTankPosition.x = windowResolution.x;
    }
    if (window->KeyHold(GLFW_KEY_UP)) {
        secondTurretRotationAngle += deltaTime;
    }
    if (window->KeyHold(GLFW_KEY_DOWN)) {
        secondTurretRotationAngle -= deltaTime;
    }

    if (window->KeyHold(GLFW_KEY_A)) {
        tankPosition.x -= tankSpeed * deltaTime;

        if (tankPosition.x < 0) tankPosition.x = 0;
    }
    if (window->KeyHold(GLFW_KEY_D)) {
        tankPosition.x += tankSpeed * deltaTime;

        if (tankPosition.x > windowResolution.x) tankPosition.x = windowResolution.x;
    }
    if (window->KeyHold(GLFW_KEY_W)) {
        turretRotationAngle += deltaTime;
    }
    if (window->KeyHold(GLFW_KEY_S)) {
        turretRotationAngle -= deltaTime;
    }
}

void Tema1::OnKeyPress(int key, int mods) {
    if (key == GLFW_KEY_SPACE) {
        LaunchProjectile(tankProjectiles, tankPosition, tankRotationAngle, turretRotationAngle);
    }
    if (key == GLFW_KEY_ENTER) {
        LaunchProjectile(secondTankProjectiles, secondTankPosition, secondTankRotationAngle, secondTurretRotationAngle);
    }
}

void Tema1::OnKeyRelease(int key, int mods) {}
void Tema1::OnMouseMove(int mouseX, int mouseY, int deltaX, int deltaY) {}
void Tema1::OnMouseBtnPress(int mouseX, int mouseY, int button, int mods) {}
void Tema1::OnMouseBtnRelease(int mouseX, int mouseY, int button, int mods) {}
void Tema1::OnMouseScroll(int mouseX, int mouseY, int offsetX, int offsetY) {}
void Tema1::OnWindowResize(int width, int height) {}
