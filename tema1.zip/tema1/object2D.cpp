﻿#include "object2D.h"

#include <vector>

#include "core/engine.h"
#include "utils/gl_utils.h"


Mesh* object2D::CreateSquare(const std::string& name, glm::vec3 leftBottomCorner, float length, glm::vec3 color, bool fill)
{
    glm::vec3 corner = leftBottomCorner;

    std::vector<VertexFormat> vertices =
    {
        VertexFormat(corner, color),
        VertexFormat(corner + glm::vec3(0, -length, 0), color),
        VertexFormat(corner + glm::vec3(length, -length, 0), color),
        VertexFormat(corner + glm::vec3(length, 0, 0), color),
    };

    Mesh* square = new Mesh(name);
    std::vector<unsigned int> indices = { 0, 1, 2, 3 };

    if (!fill) {
        square->SetDrawMode(GL_LINE_LOOP);
    }
    else {
        indices.push_back(0);
        indices.push_back(2);
    }

    square->InitFromData(vertices, indices);
    return square;
}

Mesh* object2D::CreateTrapezoid(const std::string& name, glm::vec3 center, float baseWidth, float topWidth, float height, glm::vec3 color, bool fill)
{
    float halfBaseWidth = baseWidth / 2.0f;
    float halfTopWidth = topWidth / 2.0f;

    std::vector<VertexFormat> vertices = {
        VertexFormat(center + glm::vec3(-halfBaseWidth, 0, 0), color),
        VertexFormat(center + glm::vec3(halfBaseWidth, 0, 0), color),
        VertexFormat(center + glm::vec3(halfTopWidth, height, 0), color),
        VertexFormat(center + glm::vec3(-halfTopWidth, height, 0), color)
    };

    std::vector<unsigned int> indices = { 0, 1, 2, 3, 0, 2 };

    Mesh* trapezoid = new Mesh(name);
    if (fill) {
        indices.push_back(1);
        indices.push_back(3);
    }
    else {
        trapezoid->SetDrawMode(GL_LINE_LOOP);
    }

    trapezoid->InitFromData(vertices, indices);
    return trapezoid;
}

Mesh* object2D::CreateArc(const std::string& name, glm::vec3 center, float radius, float startAngle, float endAngle, glm::vec3 color, int segments)
{
    std::vector<VertexFormat> vertices = { VertexFormat(center, color) };
    float angleStep = (endAngle - startAngle) / segments;

    for (int i = 0; i <= segments; ++i) {
        float angle = startAngle + i * angleStep;
        glm::vec3 point = center + glm::vec3(radius * cos(angle), radius * sin(angle), 0);
        vertices.push_back(VertexFormat(point, color));
    }

    std::vector<unsigned int> indices;
    for (int i = 1; i <= segments; ++i) {
        indices.push_back(0);
        indices.push_back(i);
        indices.push_back(i + 1);
    }

    Mesh* arc = new Mesh(name);
    arc->InitFromData(vertices, indices);
    return arc;
}

Mesh* object2D::CreateRectangle(const std::string& name, glm::vec3 leftBottomCorner, float width, float height, glm::vec3 color, bool fill)
{
    std::vector<VertexFormat> vertices = {
        VertexFormat(leftBottomCorner, color),
        VertexFormat(leftBottomCorner + glm::vec3(width, 0, 0), color),
        VertexFormat(leftBottomCorner + glm::vec3(width, height, 0), color),
        VertexFormat(leftBottomCorner + glm::vec3(0, height, 0), color)
    };

    Mesh* rectangle = new Mesh(name);
    std::vector<unsigned int> indices = { 0, 1, 2, 0, 2, 3 };

    if (!fill) {
        rectangle->SetDrawMode(GL_LINE_LOOP);
    }

    rectangle->InitFromData(vertices, indices);
    return rectangle;
}

Mesh* object2D::CreateCircle(const std::string& name, glm::vec3 center, float radius, glm::vec3 color, bool fill) {
    std::vector<VertexFormat> vertices;
    std::vector<unsigned int> indices;
    int segments = 20;

    if (fill) {
        vertices.push_back(VertexFormat(center, color));
        for (int i = 0; i < segments; i++) {
            float angle = 2 * M_PI * i / segments;
            vertices.push_back(VertexFormat(center + glm::vec3(radius * cos(angle), radius * sin(angle), 0), color));
            indices.push_back(0);
            indices.push_back(i + 1);
            indices.push_back((i + 1) % segments + 1);
        }
    }
    else {
        for (int i = 0; i < segments; i++) {
            float angle = 2 * M_PI * i / segments;
            vertices.push_back(VertexFormat(center + glm::vec3(radius * cos(angle), radius * sin(angle), 0), color));
            indices.push_back(i);
        }
        indices.push_back(0);
    }

    Mesh* circle = new Mesh(name);
    circle->InitFromData(vertices, indices);
    return circle;
}

Mesh* object2D::CreateLine(const std::string& name, const glm::vec2& startPoint, const glm::vec2& endPoint, const glm::vec3& color, bool fill) {
    std::vector<VertexFormat> vertices = {
        VertexFormat(glm::vec3(startPoint, 0), color),
        VertexFormat(glm::vec3(endPoint, 0), color)
    };

    std::vector<unsigned int> indices = { 0, 1 };

    Mesh* line = new Mesh(name);
    line->SetDrawMode(GL_LINES);
    line->InitFromData(vertices, indices);

    return line;
}
