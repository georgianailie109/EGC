﻿#pragma once

#include "components/simple_scene.h"
#include <vector>
#include <glm/glm.hpp>

namespace m1
{
    struct Projectile {
        glm::vec2 position;
        glm::vec2 velocity;
    };

    class Tema1 : public gfxc::SimpleScene
    {
    public:
        Tema1();
        ~Tema1();

        void Init() override;

    private:
        void FrameStart() override;
        void Update(float deltaTimeSeconds) override;
        void FrameEnd() override;

        void OnInputUpdate(float deltaTime, int mods) override;
        void OnKeyPress(int key, int mods) override;
        void OnKeyRelease(int key, int mods) override;
        void OnMouseMove(int mouseX, int mouseY, int deltaX, int deltaY) override;
        void OnMouseBtnPress(int mouseX, int mouseY, int button, int mods) override;
        void OnMouseBtnRelease(int mouseX, int mouseY, int button, int mods) override;
        void OnMouseScroll(int mouseX, int mouseY, int offsetX, int offsetY) override;
        void OnWindowResize(int width, int height) override;

        void UpdateTankYPosition(float deltaTime, glm::vec2& position, float& rotationAngle);
        void LaunchProjectile(std::vector<Projectile>& projectiles, const glm::vec2& tankPosition, float tankRotationAngle, float turretAngle);
        void UpdateProjectile(std::vector<Projectile>& projectiles, float deltaTime);
        bool CheckCollisionAndDeformTerrain(const glm::vec2& projectilePos, float deltaTime);
        void DeformTerrain(float impactX, float impactY, float radius, float deltaTime);
        void UpdateTerrainMeshes();
        void DrawTrajectory(const glm::vec2& position, float tankRotationAngle, float turretAngle, const glm::vec3& color);
        void SimulateLandslide(float deltaTime, glm::vec2 start, glm::vec2 final);
        void DrawHealthBar(const glm::vec2& position, float health);
        bool CheckCollisionWithTank(const glm::vec2& projectilePos, glm::vec2& tankPosition, float& tankHealth, bool& tankVisible);

        glm::vec2 tankPosition;
        float tankSpeed;
        float tankRotationAngle;
        float turretRotationAngle;

        glm::vec2 secondTankPosition;
        float secondTankRotationAngle;
        float secondTurretRotationAngle;

        std::vector<Projectile> tankProjectiles;
        std::vector<Projectile> secondTankProjectiles;
        float gravity = 100.0f;
        float projectileSpeed = 200.0f;

        float collisionDistance = 50.0f;
        float explosionRadius = 50.0f;
        float tankHealth = 100.0f;
        float secondTankHealth = 100.0f;
        const float tankRadius = 30.0f;
        const float projectileRadius = 25.0f;
        bool showFirstTank, showSecondTank;

        glm::vec3 groundColor;
        glm::vec3 skyColor;
        std::vector<glm::vec2> heightMap;
        std::vector<Mesh*> terrainMeshes;

        glm::vec2 start, final;
        bool terrainModified = false;
        int terrainTime = 0;

        glm::vec2 windowResolution = window->GetResolution();

    };
}