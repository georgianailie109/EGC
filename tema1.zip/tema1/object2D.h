﻿#pragma once

#include <string>
#include "core/gpu/mesh.h"
#include "utils/glm_utils.h"

namespace object2D
{
    Mesh* CreateSquare(const std::string& name, glm::vec3 leftBottomCorner, float length, glm::vec3 color, bool fill = false);
    Mesh* CreateTrapezoid(const std::string& name, glm::vec3 leftBottomCorner, float baseWidth, float topWidth, float height, glm::vec3 color, bool fill = false);
    Mesh* CreateArc(const std::string& name, glm::vec3 center, float radius, float startAngle, float endAngle, glm::vec3 color, int segments = 20);
    Mesh* CreateRectangle(const std::string& name, glm::vec3 leftBottomCorner, float width, float height, glm::vec3 color, bool fill = false);
    Mesh* CreateCircle(const std::string& name, glm::vec3 center, float radius, glm::vec3 color, bool fill = false);
    Mesh* CreateLine(const std::string& name, const glm::vec2& startPoint, const glm::vec2& endPoint, const glm::vec3& color, bool fill = false);
}
